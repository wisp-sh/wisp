// world root:component/root
export type * as WasiCliEnvironment0212 from './interfaces/wasi-cli-environment.js'; // import wasi:cli/environment@0.2.12
export type * as WasiCliExit0212 from './interfaces/wasi-cli-exit.js'; // import wasi:cli/exit@0.2.12
export type * as WasiCliStderr0212 from './interfaces/wasi-cli-stderr.js'; // import wasi:cli/stderr@0.2.12
export type * as WasiCliStdin0212 from './interfaces/wasi-cli-stdin.js'; // import wasi:cli/stdin@0.2.12
export type * as WasiCliStdout0212 from './interfaces/wasi-cli-stdout.js'; // import wasi:cli/stdout@0.2.12
export type * as WasiClocksWallClock0212 from './interfaces/wasi-clocks-wall-clock.js'; // import wasi:clocks/wall-clock@0.2.12
export type * as WasiFilesystemPreopens0212 from './interfaces/wasi-filesystem-preopens.js'; // import wasi:filesystem/preopens@0.2.12
export type * as WasiFilesystemTypes0212 from './interfaces/wasi-filesystem-types.js'; // import wasi:filesystem/types@0.2.12
export type * as WasiIoError0212 from './interfaces/wasi-io-error.js'; // import wasi:io/error@0.2.12
export type * as WasiIoStreams0212 from './interfaces/wasi-io-streams.js'; // import wasi:io/streams@0.2.12
export * as api from './interfaces/demo-rust-math-api.js'; // export demo:rust-math/api@0.1.0
