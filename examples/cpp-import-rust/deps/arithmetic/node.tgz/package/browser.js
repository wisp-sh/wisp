const __wisp_unsupported = undefined;
export { __wisp_unsupported as "_util", __wisp_unsupported as "api", __wisp_unsupported as "demo:rust-math/api@0.1.0" };
throw new Error("unsupported-browser-wasi-reactor");
