/** @module Interface demo:rust-math/api@0.1.0 **/
export function add(a0: number, a1: number): number;
export function negate(a0: boolean): boolean;
export function widen(a0: bigint): bigint;
